#!/bin/bash

# just touch /.autorelabel file to activate SELinux policy autorelabel
# for next boot

touch /.autorelabel
